#!/usr/bin/env python3
"""Flight Deals Bot - main entrypoint."""

import logging
import random
from datetime import datetime, timedelta

from bot import config
from bot.providers.skyscrapper import SkyScrapper
from bot.providers.base import FlightOffer
from bot import evaluator, telegram, state

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("main")


def _sample_dates(cfg: dict) -> list[str]:
    today = datetime.utcnow().date()
    start = today + timedelta(days=cfg["search_days_ahead_min"])
    end = today + timedelta(days=cfg["search_days_ahead_max"])
    days_range = (end - start).days
    if days_range <= 0:
        return [start.isoformat()]
    count = min(cfg["search_sample_dates"], days_range)
    offsets = sorted(random.sample(range(days_range), count))
    return [(start + timedelta(days=d)).isoformat() for d in offsets]


def main() -> None:
    cfg = config.load()

    missing = []
    if not cfg["rapidapi_key"]:
        missing.append("RAPIDAPI_KEY")
    if not cfg["telegram_token"]:
        missing.append("TELEGRAM_BOT_TOKEN")
    if not cfg["telegram_chat_id"]:
        missing.append("TELEGRAM_CHAT_ID")
    if missing:
        log.error("Missing required env vars: %s", ", ".join(missing))
        return

    provider = SkyScrapper(cfg["rapidapi_key"])
    seen = state.load(cfg["state_file"])
    all_offers: list[FlightOffer] = []

    dates = _sample_dates(cfg)
    dest_filter = cfg["destinations"] or None
    log.info("Origins: %s | Dest filter: %s | Dates: %s",
             cfg["origins"], dest_filter or "ALL", dates)

    for orig in cfg["origins"]:
        for dep in dates:
            offers = provider.search_everywhere(orig, dep, cfg["currency"], dest_filter)
            all_offers.extend(offers)
            log.info("  %s on %s → %d offers", orig, dep, len(offers))

    log.info("Total offers fetched: %d", len(all_offers))

    deals = evaluator.evaluate(all_offers, seen, cfg["max_price"], cfg["improvement_pct"])
    deals.sort(key=lambda o: o.price)
    log.info("Deals passing filter: %d", len(deals))

    if deals:
        sent = telegram.send_deals(cfg["telegram_token"], cfg["telegram_chat_id"],
                                   deals, cfg["max_posts_per_run"])
        log.info("Telegram messages sent: %d", sent)
        evaluator.update_state(seen, deals[:cfg["max_posts_per_run"]])
    else:
        log.info("No new deals to post.")

    state.save(cfg["state_file"], seen)


if __name__ == "__main__":
    main()
