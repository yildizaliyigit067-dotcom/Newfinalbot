"""Send deal alerts to Telegram via Bot API."""

import logging
import time
import requests
from bot.providers.base import FlightOffer

log = logging.getLogger(__name__)

API = "https://api.telegram.org/bot{token}/sendMessage"


def _escape(text: str) -> str:
    for ch in r"\_*[]()~`>#+-=|{}.!":
        text = text.replace(ch, f"\\{ch}")
    return text


def _format(offer: FlightOffer) -> str:
    trip = "↔️" if offer.trip_type == "round_trip" else "→"
    stops_txt = "Direct" if offer.stops == 0 else f"{offer.stops} stop{'s' if offer.stops > 1 else ''}"
    lines = [
        f"✈️  *{_escape(offer.origin)} {trip} {_escape(offer.destination)}*",
        f"💰  *{_escape(f'{offer.price:.0f} {offer.currency}')}*  \\({_escape(stops_txt)}\\)",
        f"📅  {_escape(offer.departure_date)}" + (f" — {_escape(offer.return_date)}" if offer.return_date else ""),
        f"🏷  {_escape(offer.airline)}",
    ]
    reason = offer.raw.get("_reason", "")
    if reason:
        lines.append(f"📉  _{_escape(reason)}_")
    if offer.booking_link:
        lines.append(f"[🔗 Book / Search]({offer.booking_link})")
    return "\n".join(lines)


def send_deals(token: str, chat_id: str, deals: list[FlightOffer], max_posts: int) -> int:
    url = API.format(token=token)
    sent = 0
    for deal in deals[:max_posts]:
        text = _format(deal)
        try:
            resp = requests.post(url, json={
                "chat_id": chat_id,
                "text": text,
                "parse_mode": "MarkdownV2",
                "disable_web_page_preview": True,
            }, timeout=15)
            if resp.status_code == 200:
                sent += 1
                log.info("Posted: %s→%s %.0f %s",
                         deal.origin, deal.destination, deal.price, deal.currency)
            else:
                log.error("Telegram %d: %s", resp.status_code, resp.text[:300])
        except requests.RequestException as e:
            log.error("Telegram send error: %s", e)
        time.sleep(1.5)
    return sent
