"""Evaluate which offers are worth posting."""

import logging
from bot.providers.base import FlightOffer

log = logging.getLogger(__name__)


def evaluate(offers: list[FlightOffer], state: dict,
             max_price: float, improvement_pct: float) -> list[FlightOffer]:
    deals: list[FlightOffer] = []
    for o in offers:
        if o.price > max_price:
            continue
        key = o.deal_key
        prev = state.get(key)
        if prev:
            old_price = prev["price"]
            drop = (old_price - o.price) / old_price * 100 if old_price > 0 else 0
            if drop < improvement_pct:
                continue
            o.raw["_reason"] = f"Price dropped {drop:.0f}% (was {old_price:.0f})"
        else:
            o.raw["_reason"] = f"New deal under {max_price} {o.currency}"
        deals.append(o)
    return deals


def update_state(state: dict, offers: list[FlightOffer]) -> None:
    for o in offers:
        state[o.deal_key] = {
            "price": o.price,
            "currency": o.currency,
            "departure_date": o.departure_date,
        }
