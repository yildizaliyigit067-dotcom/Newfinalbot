"""Persist seen deals as a JSON file committed back to the repo."""

import json
import logging
import os
from datetime import datetime

log = logging.getLogger(__name__)


def load(path: str) -> dict:
    if not os.path.exists(path):
        return {}
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        log.warning("Could not load state file, starting fresh: %s", e)
        return {}


def save(path: str, state: dict) -> None:
    cutoff = datetime.utcnow().strftime("%Y-%m-%d")
    pruned = {k: v for k, v in state.items()
              if v.get("departure_date", "9999") >= cutoff}
    with open(path, "w") as f:
        json.dump(pruned, f, indent=1, sort_keys=True)
    log.info("State saved with %d entries", len(pruned))
