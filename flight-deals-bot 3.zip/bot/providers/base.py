"""Abstract base for flight search providers."""

from dataclasses import dataclass, field


@dataclass
class FlightOffer:
    origin: str
    destination: str
    departure_date: str
    return_date: str | None
    price: float
    currency: str
    airline: str
    trip_type: str
    stops: int = 0
    booking_link: str = ""
    raw: dict = field(default_factory=dict, repr=False)

    @property
    def deal_key(self) -> str:
        return f"{self.origin}-{self.destination}|{self.departure_date}|{self.return_date or 'OW'}|{self.airline}"


class BaseProvider:
    def search(self, origin: str, destination: str, date_from: str,
               date_to: str, return_from: str | None, return_to: str | None,
               currency: str, max_results: int) -> list[FlightOffer]:
        raise NotImplementedError
