"""Sky Scrapper (RapidAPI) provider — uses Skyscanner data."""

import logging
import requests
from .base import BaseProvider, FlightOffer

log = logging.getLogger(__name__)

SEARCH_URL = "https://sky-scrapper.p.rapidapi.com/api/v1/flights/searchFlightEverywhere"
API_HOST = "sky-scrapper.p.rapidapi.com"


class SkyScrapper(BaseProvider):
    def __init__(self, api_key: str):
        self._key = api_key

    def search_everywhere(self, origin: str, departure_date: str,
                          currency: str, destination_filter: list[str] | None = None) -> list[FlightOffer]:
        """Search cheapest flights from origin to everywhere, optionally filter destinations."""
        params = {
            "originSkyId": origin,
            "travelDate": departure_date,
            "currency": currency,
        }
        headers = {
            "X-RapidAPI-Key": self._key,
            "X-RapidAPI-Host": API_HOST,
        }
        try:
            resp = requests.get(SEARCH_URL, params=params, headers=headers, timeout=25)
            if resp.status_code == 429:
                log.warning("Rate limited for %s", origin)
                return []
            if resp.status_code != 200:
                log.warning("SkyScrapper %d for %s: %s", resp.status_code, origin, resp.text[:200])
                return []
        except requests.RequestException as e:
            log.error("SkyScrapper request error for %s: %s", origin, e)
            return []

        return self._parse(resp.json(), origin, departure_date, currency, destination_filter)

    # keep BaseProvider interface working too
    def search(self, origin, destination, departure_date, return_date, currency, max_results):
        return self.search_everywhere(origin, departure_date, currency, [destination])

    @staticmethod
    def _parse(data: dict, origin: str, dep_date: str, currency: str,
               dest_filter: list[str] | None) -> list[FlightOffer]:
        offers: list[FlightOffer] = []
        items = data.get("data", [])
        if not isinstance(items, list):
            return []

        # normalize filter to uppercase set
        filt = {d.upper() for d in dest_filter} if dest_filter else None

        for item in items:
            try:
                meta = item.get("Meta", {})
                payload = item.get("Payload", {})

                country_name = meta.get("CountryNameEnglish", "")
                city_name = meta.get("CityNameEnglish", meta.get("CityName", ""))
                sky_id = meta.get("SkyId", "")
                dest_code = sky_id or city_name[:3].upper()

                # filter by destination if provided
                if filt and dest_code.upper() not in filt and country_name.upper()[:2] not in filt:
                    # also try matching city name
                    if city_name.upper() not in filt:
                        continue

                price = payload.get("Price")
                if price is None:
                    continue
                price = float(price)

                link = (f"https://www.skyscanner.com/transport/flights/"
                        f"{origin.lower()}/{dest_code.lower()}/{dep_date.replace('-', '')}/"
                        f"?adultsv2=1&currency={currency}")

                offers.append(FlightOffer(
                    origin=origin,
                    destination=dest_code,
                    departure_date=dep_date,
                    return_date=None,
                    price=price,
                    currency=currency,
                    airline=country_name,  # API gives country/city, not airline
                    trip_type="one_way",
                    stops=0,
                    booking_link=link,
                ))
            except (KeyError, ValueError, TypeError) as e:
                log.debug("Skipping malformed offer: %s", e)
        return offers
