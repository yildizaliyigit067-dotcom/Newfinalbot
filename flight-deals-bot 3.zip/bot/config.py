"""Configuration loaded from environment variables with sensible defaults."""

import os


def _csv(val: str) -> list[str]:
    return [v.strip() for v in val.split(",") if v.strip()]


def load() -> dict:
    origins = _csv(os.getenv("ORIGINS", "IST,SAW,ESB,ADB,AYT"))
    destinations = _csv(os.getenv("DESTINATIONS", ""))  # empty = show all
    return {
        "origins": origins,
        "destinations": destinations,
        "max_price": int(os.getenv("MAX_PRICE", "150")),
        "currency": os.getenv("CURRENCY", "EUR"),
        "search_days_ahead_min": int(os.getenv("SEARCH_DAYS_AHEAD_MIN", "7")),
        "search_days_ahead_max": int(os.getenv("SEARCH_DAYS_AHEAD_MAX", "60")),
        "search_sample_dates": int(os.getenv("SEARCH_SAMPLE_DATES", "3")),
        "improvement_pct": float(os.getenv("IMPROVEMENT_PCT", "10")),
        "rapidapi_key": os.getenv("RAPIDAPI_KEY", ""),
        "telegram_token": os.getenv("TELEGRAM_BOT_TOKEN", ""),
        "telegram_chat_id": os.getenv("TELEGRAM_CHAT_ID", ""),
        "state_file": os.getenv("STATE_FILE", "state.json"),
        "max_posts_per_run": int(os.getenv("MAX_POSTS_PER_RUN", "10")),
    }
